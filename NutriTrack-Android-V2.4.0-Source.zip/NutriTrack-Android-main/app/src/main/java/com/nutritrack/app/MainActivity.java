package com.nutritrack.app;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.graphics.Color;
import android.util.Base64;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.Window;
import android.content.ContentValues;
import android.widget.Toast;

import com.googlecode.tesseract.android.TessBaseAPI;
import com.google.mlkit.vision.barcode.common.Barcode;
import com.google.mlkit.vision.codescanner.GmsBarcodeScanner;
import com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions;
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning;

import java.net.HttpURLConnection;
import java.net.URL;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_CHOOSER_REQUEST = 1001;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window w = getWindow();
        w.setStatusBarColor(Color.rgb(18, 60, 50));
        w.setNavigationBarColor(Color.rgb(18, 60, 50));
        w.getDecorView().setSystemUiVisibility(0);

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(245, 247, 243));
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setDatabaseEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.getSettings().setAllowContentAccess(true);
        webView.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                return !"file".equals(uri.getScheme());
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                try {
                    Intent intent = params.createIntent();
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    startActivityForResult(Intent.createChooser(intent, "Choose photo or backup file"), FILE_CHOOSER_REQUEST);
                } catch (Exception e) {
                    filePathCallback = null;
                    return false;
                }
                return true;
            }
        });
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    public class AndroidBridge {
        @JavascriptInterface
        public void scanBarcode() {
            runOnUiThread(() -> {
                try {
                    GmsBarcodeScannerOptions options = new GmsBarcodeScannerOptions.Builder()
                            .setBarcodeFormats(Barcode.FORMAT_EAN_13, Barcode.FORMAT_EAN_8,
                                    Barcode.FORMAT_UPC_A, Barcode.FORMAT_UPC_E, Barcode.FORMAT_QR_CODE)
                            .enableAutoZoom()
                            .build();
                    GmsBarcodeScanner scanner = GmsBarcodeScanning.getClient(MainActivity.this, options);
                    scanner.startScan()
                            .addOnSuccessListener(result -> {
                                String value = result == null ? "" : result.getRawValue();
                                sendBarcodeResult(value, "");
                            })
                            .addOnCanceledListener(() -> sendBarcodeResult("", "Scan cancelled"))
                            .addOnFailureListener(error -> sendBarcodeResult("", "Scanner unavailable: " +
                                    (error.getMessage() == null ? "Google Play services may need updating" : error.getMessage())));
                } catch (Exception e) {
                    sendBarcodeResult("", "Could not start scanner: " + e.getMessage());
                }
            });
        }

        private void sendBarcodeResult(String value, String error) {
            if (webView == null) return;
            String js = "window.onNativeBarcodeResult && window.onNativeBarcodeResult(" +
                    org.json.JSONObject.quote(value == null ? "" : value) + "," +
                    org.json.JSONObject.quote(error == null ? "" : error) + ");";
            runOnUiThread(() -> { if (webView != null) webView.evaluateJavascript(js, null); });
        }

        @JavascriptInterface
        public void lookupProductByBarcode(String code) {
            new Thread(() -> {
                String payload = "";
                String error = "";
                HttpURLConnection connection = null;
                try {
                    String digits = code == null ? "" : code.replaceAll("\\D", "");
                    if (digits.length() < 8 || digits.length() > 14) throw new IOException("INVALID");
                    URL url = new URL("https://world.openfoodfacts.org/api/v2/product/" + digits + ".json");
                    connection = (HttpURLConnection) url.openConnection();
                    connection.setRequestMethod("GET");
                    connection.setConnectTimeout(12000);
                    connection.setReadTimeout(15000);
                    connection.setRequestProperty("Accept", "application/json");
                    connection.setRequestProperty("User-Agent", "NutriTrack/2.3 Android");
                    int status = connection.getResponseCode();
                    if (status != 200) throw new IOException("HTTP");
                    StringBuilder body = new StringBuilder();
                    try (InputStream in = connection.getInputStream();
                         java.io.InputStreamReader reader = new java.io.InputStreamReader(in, java.nio.charset.StandardCharsets.UTF_8);
                         java.io.BufferedReader buffered = new java.io.BufferedReader(reader)) {
                        String line;
                        while ((line = buffered.readLine()) != null) body.append(line);
                    }
                    org.json.JSONObject root = new org.json.JSONObject(body.toString());
                    if (root.optInt("status", 0) != 1 || !root.has("product")) {
                        error = "NOT_FOUND";
                    } else {
                        payload = root.toString();
                    }
                } catch (Exception e) {
                    String message = e.getMessage();
                    error = "INVALID".equals(message) ? "INVALID" :
                            (e instanceof java.net.SocketTimeoutException ? "TIMEOUT" : "NETWORK");
                } finally {
                    if (connection != null) connection.disconnect();
                }
                final String resultJson = payload;
                final String resultError = error;
                String js = "window.onNativeProductLookupResult && window.onNativeProductLookupResult(" +
                        org.json.JSONObject.quote(code == null ? "" : code) + "," +
                        org.json.JSONObject.quote(resultJson) + "," +
                        org.json.JSONObject.quote(resultError) + ");";
                runOnUiThread(() -> { if (webView != null) webView.evaluateJavascript(js, null); });
            }, "NutriTrack-BarcodeLookup").start();
        }

        // Runs off the WebView thread: first-use language downloads and OCR must never freeze the UI.
        @JavascriptInterface
        public void recognizeNutritionLabelAsync(String imageDataUrl, String callbackId) {
            new Thread(() -> {
                TessBaseAPI tess = null;
                Bitmap bitmap = null;
                String result;
                try {
                    if (imageDataUrl == null) throw new IOException("No image was supplied");
                    int comma = imageDataUrl.indexOf(',');
                    String encoded = comma >= 0 ? imageDataUrl.substring(comma + 1) : imageDataUrl;
                    byte[] imageBytes = Base64.decode(encoded, Base64.DEFAULT);
                    BitmapFactory.Options options = new BitmapFactory.Options();
                    options.inPreferredConfig = Bitmap.Config.ARGB_8888;
                    bitmap = BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.length, options);
                    if (bitmap == null) throw new IOException("Could not decode image");

                    File baseDir = new File(getFilesDir(), "nutritrack-ocr");
                    File dataDir = new File(baseDir, "tessdata");
                    if (!dataDir.exists() && !dataDir.mkdirs()) throw new IOException("Cannot create OCR data folder");
                    ensureLanguageFile(dataDir, "eng");
                    ensureLanguageFile(dataDir, "ara");
                    ensureLanguageFile(dataDir, "fra");

                    tess = new TessBaseAPI();
                    if (!tess.init(baseDir.getAbsolutePath(), "eng+fra+ara")) {
                        throw new IOException("OCR engine could not initialize");
                    }
                    // Nutrition labels are small: upscale and enhance contrast before recognition.
                    Bitmap enhanced = enhanceForOcr(bitmap);
                    StringBuilder combined = new StringBuilder();
                    TessBaseAPI.PageSegMode[] modes = new TessBaseAPI.PageSegMode[] {
                            TessBaseAPI.PageSegMode.PSM_AUTO,
                            TessBaseAPI.PageSegMode.PSM_SINGLE_BLOCK,
                            TessBaseAPI.PageSegMode.PSM_SPARSE_TEXT
                    };
                    for (TessBaseAPI.PageSegMode mode : modes) {
                        tess.setPageSegMode(mode);
                        tess.setImage(enhanced);
                        String pass = tess.getUTF8Text();
                        if (pass != null && !pass.trim().isEmpty()) {
                            if (combined.length() > 0) combined.append("\n\n--- OCR PASS ---\n");
                            combined.append(pass.trim());
                        }
                        tess.clear();
                    }
                    result = combined.toString();
                    if (enhanced != bitmap && !enhanced.isRecycled()) enhanced.recycle();
                    if (result.trim().isEmpty()) result = "No readable text found. Try a closer, sharper photo with the label filling the frame.";
                } catch (Exception e) {
                    result = "ERROR:" + (e.getMessage() == null ? "OCR failed" : e.getMessage());
                } finally {
                    if (tess != null) {
                        try { tess.clear(); tess.recycle(); } catch (Exception ignored) { }
                    }
                    if (bitmap != null && !bitmap.isRecycled()) bitmap.recycle();
                }
                final String output = result;
                String js = "window.onNutritionOcrResult && window.onNutritionOcrResult(" +
                        org.json.JSONObject.quote(callbackId == null ? "" : callbackId) + "," +
                        org.json.JSONObject.quote(output) + ");";
                runOnUiThread(() -> { if (webView != null) webView.evaluateJavascript(js, null); });
            }, "NutriTrack-OCR").start();
        }

        private Bitmap enhanceForOcr(Bitmap source) {
            int sw = source.getWidth(), sh = source.getHeight();
            float scale = Math.min(2.5f, 2400f / Math.max(sw, sh));
            int width = Math.max(1, Math.round(sw * scale));
            int height = Math.max(1, Math.round(sh * scale));
            Bitmap scaled = Bitmap.createScaledBitmap(source, width, height, true);
            Bitmap enhanced = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
            int[] pixels = new int[width * height];
            scaled.getPixels(pixels, 0, width, 0, 0, width, height);
            for (int i = 0; i < pixels.length; i++) {
                int c = pixels[i];
                int r = (c >> 16) & 255, g = (c >> 8) & 255, b = c & 255;
                int gray = (int)(0.299 * r + 0.587 * g + 0.114 * b);
                int contrast = Math.max(0, Math.min(255, (int)((gray - 128) * 1.55 + 128)));
                pixels[i] = Color.rgb(contrast, contrast, contrast);
            }
            enhanced.setPixels(pixels, 0, width, 0, 0, width, height);
            if (scaled != source && !scaled.isRecycled()) scaled.recycle();
            return enhanced;
        }

        private void ensureLanguageFile(File dataDir, String language) throws IOException {
            File target = new File(dataDir, language + ".traineddata");
            if (target.exists() && target.length() > 100000) return;
            URL url = new URL("https://raw.githubusercontent.com/tesseract-ocr/tessdata_fast/main/" + language + ".traineddata");
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setConnectTimeout(20000);
            connection.setReadTimeout(60000);
            connection.setInstanceFollowRedirects(true);
            try {
                int code = connection.getResponseCode();
                if (code != 200) throw new IOException("Could not download " + language + " OCR data (HTTP " + code + ")");
                File temp = new File(dataDir, language + ".traineddata.tmp");
                try (InputStream in = connection.getInputStream(); FileOutputStream out = new FileOutputStream(temp)) {
                    byte[] buffer = new byte[8192];
                    int count;
                    while ((count = in.read(buffer)) != -1) out.write(buffer, 0, count);
                }
                if (!temp.renameTo(target)) {
                    temp.delete();
                    throw new IOException("Could not save OCR language data");
                }
            } finally {
                connection.disconnect();
            }
        }

        @JavascriptInterface
        public void saveFile(String filename, String base64Data, String mimeType) {
            try {
                byte[] bytes = Base64.decode(base64Data, Base64.DEFAULT);
                String safeName = filename == null ? "nutritrack-export" : filename.replaceAll("[^a-zA-Z0-9._-]", "_");
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.Downloads.DISPLAY_NAME, safeName);
                    values.put(MediaStore.Downloads.MIME_TYPE, mimeType == null ? "application/octet-stream" : mimeType);
                    values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/NutriTrack");
                    values.put(MediaStore.Downloads.IS_PENDING, 1);
                    Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                    if (uri == null) throw new IOException("Could not create download");
                    try (OutputStream out = getContentResolver().openOutputStream(uri)) { out.write(bytes); }
                    values.clear();
                    values.put(MediaStore.Downloads.IS_PENDING, 0);
                    getContentResolver().update(uri, values, null, null);
                } else {
                    File dir = new File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "NutriTrack");
                    if (!dir.exists()) dir.mkdirs();
                    try (FileOutputStream out = new FileOutputStream(new File(dir, safeName))) { out.write(bytes); }
                }
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "Saved to Downloads / NutriTrack", Toast.LENGTH_LONG).show());
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "Could not save export: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST && filePathCallback != null) {
            Uri result = (resultCode == RESULT_OK && data != null) ? data.getData() : null;
            filePathCallback.onReceiveValue(result == null ? null : new Uri[]{result});
            filePathCallback = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) { webView.destroy(); webView = null; }
        super.onDestroy();
    }
}
